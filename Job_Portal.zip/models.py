from app import db

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150))
    password = db.Column(db.String(150))
    role = db.Column(db.String(20))  # 'seeker', 'employer', 'admin'

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    description = db.Column(db.Text)
    salary = db.Column(db.String(50))
    location = db.Column(db.String(100))
    posted_by = db.Column(db.Integer, db.ForeignKey('user.id'))